--blocks

minetest.register_node("efficionite_mod:efficionite_block", {
  description = "efficionite block",
  tiles = {"eff_block.png"},
  groups = {cracky=1},
})

--items

minetest.register_craftitem("efficionite_mod:efficionite_ingot", {
    description = "efficionite ingot",
    inventory_image = "eff_ingot.png",
})

minetest.register_craftitem("efficionite_mod:diamond_plated_gold", {
    description = "diamond plated gold",
    inventory_image = "dpg.png",
})

--tools

minetest.register_tool("efficionite_mod:efficionite_sword", {
    description = "efficionite sword",
    inventory_image = "es.png",
    tool_capabilities = {
        full_punch_interval = 1.5,
        max_drop_level = 1,
        groupcaps = {
            crumbly = {
                maxlevel = 2,
                uses = 20000,
                times = { [1]=1.60, [2]=1.20, [3]=0.80 }
            },
        },
        damage_groups = {fleshy=1},
    },
})

minetest.register_tool("efficionite_mod:efficionite_shovel", {
    description = "efficionite shovel",
    inventory_image = "esh.png",
    tool_capabilities = {
        full_punch_interval = 1.5,
        max_drop_level = 1,
        groupcaps = {
            crumbly = {
                maxlevel = 1,
                uses = 20000,
                times = { [1]=1.60, [2]=1.20, [3]=0.80 }
            },
        },
        damage_groups = {fleshy=2},
    },
})

minetest.register_tool("efficionite_mod:efficionite_pickaxe", {
    description = "efficionite pickaxe",
    inventory_image = "ep.png",
    tool_capabilities = {
        full_punch_interval = 1.5,
        max_drop_level = 1,
        groupcaps = {
            cracky = {
                maxlevel = 2,
                uses = 20000,
                times = { [1]=1.60, [2]=1.20, [3]=0.80 }
            },
        },
        damage_groups = {fleshy=2},
    },
})

minetest.register_tool("efficionite_mod:efficionite_axe", {
    description = "efficionite axe",
    inventory_image = "ea.png",
    tool_capabilities = {
        full_punch_interval = 1.5,
        max_drop_level = 1,
        groupcaps = {
            choppy = {
                maxlevel = 2,
                uses = 20000,
                times = { [1]=1.60, [2]=1.20, [3]=0.80 }
            },
        },
        damage_groups = {fleshy=2},
    },
})

--crafting

minetest.register_craft({
  output = "efficionite_mod:efficionite_block",
  recipe = {{"efficionite_mod:efficionite_ingot", "efficionite_mod:efficionite_ingot", "efficionite_mod:efficionite_ingot"},
            {"efficionite_mod:efficionite_ingot", "efficionite_mod:efficionite_ingot", "efficionite_mod:efficionite_ingot"},
            {"efficionite_mod:efficionite_ingot", "efficionite_mod:efficionite_ingot", "efficionite_mod:efficionite_ingot"},
 },
})

minetest.register_craft({
  output = "efficionite_mod:diamond_plated_gold",
  recipe = {{"default:diamond", "default:diamond", "default:diamond"},
            {"default:diamond", "default:gold_ingot", "default:diamond"},
            {"default:diamond", "default:diamond", "default:diamond"},
 },
})

minetest.register_craft({
  output = "efficionite_mod:efficionite_ingot",
  recipe = {{"default:tin_ingot", "default:tin_ingot", "default:tin_ingot"},
            {"default:tin_ingot", "efficionite_mod:diamond_plated_gold", "default:tin_ingot"},
            {"default:tin_ingot", "default:tin_ingot", "default:tin_ingot"},
 },
})

minetest.register_craft({
  output = "efficionite_mod:efficionite_pickaxe",
  recipe = {{"efficionite_mod:efficionte_ingot", "efficionite_mod:efficionite_ingot", "efficionite_mod:efficionite_ingot"},
            {"", "default:stick", ""},
            {"", "default:stick", ""},
 },
})

minetest.register_craft({
  output = "efficionite_mod:efficionite_sword",
  recipe = {{"", "efficionite_mod:efficionite_ingot", ""},
            {"", "efficionite_mod:efficionite_ingot", ""},
            {"", "default:stick", ""},
 },
})

minetest.register_craft({
  output = "efficionite_mod:efficionite_shovel",
  recipe = {{"", "efficionite_mod:efficionite_ingot", ""},
            {"", "default:stick", ""},
            {"", "default:stick", ""},
 },
})

minetest.register_craft({
  output = "efficionite_mod:efficionite_axe",
  recipe = {{"efficionite_mod:efficionite_ingot", "efficionite_mod:efficionite_ingot", ""},
            {"efficionite_mod:efficionite_ingot", "default:stick", ""},
            {"", "default:stick", ""},
 },
})