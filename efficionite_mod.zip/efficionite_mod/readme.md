efficionite mod
===============

adds efficionite tools and a block.

Version: 1.0.0
License: LGPL 2.1 or later
Dependencies: default mod (found in minetest_game)

Report bugs or request help on the forum topic.

Installation
------------

Unzip the archive, rename the folder to efficionite_mod and
place it in minetest/mods/

(  GNU/Linux: If you use a system-wide installation place
	it in ~/.minetest/mods/.  )

(  If you only want this to be used in a single world, place
	the folder in worldmods/ in your worlddirectory.  )

For further information or help see:
http://wiki.minetest.com/wiki/Installing_Mods